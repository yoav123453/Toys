package yoav.solar.model;
import java.util.ArrayList;
import yoav.solar.model.BaseEntity;
public class BaseList<TEntity extends BaseEntity, TCollection> extends ArrayList<TEntity> {
}
